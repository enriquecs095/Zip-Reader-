#include "MyGame.h"

void MyGame::run()
{
    CColor color;
    con.setForecolor(CColor::Grey);
    con.setBackcolor(CRGBColor(0xe4, 0xe4, 0x00));
    con.clearScreen();
    con.setCursor(10, 10);
    con.setForecolor(CColor::Red1);
    con << "\x1\x2\x3";
    con.setForecolor(CColor::White);
    con.setCursor(0, 0);
    con.writeString("Hola Mundo\n");
    con.setCursor(4, 10);
    con.setForecolor(CColor::Blue);
    con.setCursor(10,10);
    con << "Hello World!\nHola Mundo " << con.getColCount() 
        << ":" << con.getRowCount() << '\n';
    con.setForecolor(CColor::White);
    con.refresh();
    con.delayMs(1000);
    con << "After delay\n";

    con.refresh();
    con.flushKeybuffer();
    while (con.isActive()) {
        uint32_t key = con.getKey();
        if (key != SDLK_UNKNOWN) {
            switch (key) {
                case SDLK_LEFT:
                    con << "LEFT pressed\n";
                    break;
                case SDLK_RIGHT:
                    con << "RIGHT pressed\n";
                    break;
                case SDLK_UP:
                    con << "UP pressed\n";
                    break;
                case SDLK_DOWN:
                    con << "DOWN pressed\n";
                    break;
                case SDLK_F1:
                    con << "F1 pressed\n";
                    break;
                default:
                    con << "Other key pressed\n";
            }
            con.refresh();
        }
    }
}