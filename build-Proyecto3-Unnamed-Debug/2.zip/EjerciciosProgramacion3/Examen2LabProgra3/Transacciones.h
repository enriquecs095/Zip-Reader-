#pragma once
#ifndef TRANSACCIONES_H
#define TRANSACCIONES_H

struct Cliente{
int codigo;
char nombre[30];
char genero;
float cuenta;

};

struct Saldo{
double saldoC;
float cuenta;
};

struct Transaccion{
int cuenta;
int tipoTR;
double cantidad;

};


class Transacciones{
public:
void AgregarAfiliados();
void ConsultarAfiliados();
void RegistrarTransacciones();
int RegistrarSaldos();
int siExiste(int);
bool SaldoDisponible(double);
void ConsultarTransacciones();

Transacciones();

};

#endif
