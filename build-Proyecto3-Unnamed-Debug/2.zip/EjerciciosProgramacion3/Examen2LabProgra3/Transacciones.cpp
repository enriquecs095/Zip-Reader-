#include "Transacciones.h"
#include <fstream>
#include <iostream>
#include <cstring>

Transacciones::Transacciones(){}


void Transacciones::AgregarAfiliados(){
Cliente cliente;
Saldo saldo;
std::ofstream ArchivoE("afiliados.dat", std::ios::binary | std::ios::app);
std::ofstream ArchivoE2("saldos.dat", std::ios::binary | std::ios::app);
if(!ArchivoE && !ArchivoE2){
    std::cout<<"Error al abrir archivos\n";
} else{
std::cout<<"Ingrese el codigo del afiliado: ";
std::cin>>cliente.codigo;
std::cout<<"Ingrese el nombre del afiliado: ";
std::cin>>cliente.nombre;
std::cout<<"Ingrese el genero del afiliado : ";
std::cin>>cliente.genero;
std::cout<<"Ingrese el numero de cuenta del afiliado : ";
std::cin>>cliente.cuenta;
saldo.cuenta=cliente.cuenta;
saldo.saldoC=0;
ArchivoE.write(reinterpret_cast<const char *>(&cliente), sizeof(Cliente));
ArchivoE2.write(reinterpret_cast<const char *>(&saldo), sizeof(Saldo));
}
ArchivoE.close();
ArchivoE2.close();
}

void Transacciones::ConsultarAfiliados(){
    int contador=1;
    Saldo saldo;
   std::ifstream ArchivoE("saldos.dat", std::ios::in | std::ios::binary);
if(!ArchivoE){
    std::cout<<"Error al abrir el archivo\n";
} else{
    ArchivoE.read(reinterpret_cast<char *>(&saldo), sizeof(Saldo));
    while(!ArchivoE.eof()){
    std::cout<<"Cliente "<< contador <<" { "<< saldo.cuenta<<" "<<saldo.saldoC<< " } "<<"\n";
    contador++;
      ArchivoE.read(reinterpret_cast<char*>(&saldo), sizeof(Saldo));
    }
}
ArchivoE.close();
}

void Transacciones::RegistrarTransacciones(){
    int Ncuenta;
    int TipoT;
    double cantidad;
Transaccion transaccion; 
Saldo saldo;   
    std::ofstream ArchivoE("saldos.dat",std::ios::in |std::ios::binary);
    std::ofstream ArchivoT("transacciones.dat",std::ios::binary | std::ios::app);
if(!ArchivoE && !ArchivoT){
    std::cout<<"Error al abrir archivo\n";
}else {
    std::cout<<"Ingrese el numero de cuenta: ";
    std::cin>>Ncuenta;
      if(siExiste(Ncuenta)==1){
          std::cout<<"Ingrese el tipo de transacciones: 1. Retiro 2. Deposito\n";
          std::cin>>TipoT;
          std::cout<<"Ingrese la cantidad: ";
          std::cin>>cantidad;
          if(TipoT==1){
           if(!SaldoDisponible(cantidad)){
               std::cout<<"Saldo insuficiente para realizar transaccion";
           }else{
            //si hay saldo para el retiro;    
            transaccion.cuenta=Ncuenta;
            transaccion.tipoTR=1;           
            transaccion.cantidad=cantidad;
           }
          }else {
            transaccion.cuenta=Ncuenta;
            transaccion.tipoTR=2;           
            transaccion.cantidad=cantidad;
              //tipo 2 deposito
           } 
            ArchivoT.write(reinterpret_cast<char*>(&transaccion), sizeof(Transaccion));
          }else {
        std::cout<<"Cuenta no existe\n";
    }
 }
 ArchivoT.close();
}
    


int Transacciones::siExiste(int Ncuenta){
Cliente cliente;  
    std::ifstream ArchivoL("afiliados.dat", std::ios::binary | std::ios::app);
if(!ArchivoL){
std::cout<<"Error al abrir archivo\n";
}else {
    ArchivoL.read(reinterpret_cast<char*>(&cliente), sizeof(Cliente));
while(!ArchivoL.eof()){
    if(Ncuenta==cliente.cuenta){
          return 1;
    }else {
        return 2;
    }
  ArchivoL.read(reinterpret_cast<char*>(&cliente), sizeof(Cliente));
}
ArchivoL.close();
}
return 0;
}

bool Transacciones::SaldoDisponible(double cantidad){
 Saldo saldo;    
 std::ifstream ArchivoL("saldos.dat", std::ios::in | std::ios::binary);
if(!ArchivoL){
std::cout<<"Error al abrir archivo\n";
}else {
     ArchivoL.read(reinterpret_cast<char*>(&saldo), sizeof(Saldo));
    while(!ArchivoL.eof()){
        if(cantidad>saldo.saldoC){
            return false;
        }
         ArchivoL.read(reinterpret_cast<char*>(&saldo), sizeof(Saldo));
    }
    ArchivoL.close();
}
return true;
}


void Transacciones::ConsultarTransacciones(){
    std::string tipoTransaccion;
std::ifstream ArchivoL("transacciones.dat", std::ios::binary | std::ios::app);
if(!ArchivoL){
std::cout<<"Error al abrir archivo\n";
}else {
    Transaccion transaccion;
     ArchivoL.read(reinterpret_cast<char*>(&transaccion), sizeof(Transaccion));
    while(!ArchivoL.eof()){
        if(transaccion.tipoTR==1){
            tipoTransaccion="Retiro";
        }else {
            tipoTransaccion="Deposito";
        }
          std::cout<<transaccion.cuenta<<" "<<tipoTransaccion<<" "<<transaccion.cantidad;

               ArchivoL.read(reinterpret_cast<char*>(&transaccion), sizeof(Transaccion));
        }
        std::cout<<"\n";
        ArchivoL.close();
    }
}