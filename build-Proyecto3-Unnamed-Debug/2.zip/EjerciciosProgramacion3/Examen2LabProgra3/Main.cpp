#include <iostream>
#include "Transacciones.h"

int main(){

int opcion;
bool salir=false;
Transacciones transacciones;
do{
std::cout<<"Banco de Enrique Cruz\n";
std::cout<<"1. Ingresar afiliado\n";
std::cout<<"2. Consultar Afiliados\n";
std::cout<<"3. Ingresar transaccion\n";
std::cout<<"4. Consultar transaccion\n";
std::cout<<"5. Salir\n";
std::cout<<"Ingrese una opcion: ";
std::cin>>opcion;

switch(opcion){

case 1:
        transacciones.AgregarAfiliados();
        break;
    
case 2: 
        transacciones.ConsultarAfiliados();
 break;       


case 3:
        transacciones.RegistrarTransacciones();
    break;

case 4:
transacciones.ConsultarTransacciones();

break;

case 5:
    salir=true;
    break;
    default:
    std::cout<<"Ingrese una opcion correcta\n";
    break;

}
}while(!salir);

}