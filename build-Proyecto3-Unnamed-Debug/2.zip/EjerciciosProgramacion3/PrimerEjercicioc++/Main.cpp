
#include <iostream>
#include "Rectangulo.h"

int main(){

Rectangulo r1;
Rectangulo r2(4, 6);

r1.Imprimir();
r2.Imprimir();

}