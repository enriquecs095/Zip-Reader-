#include <iostream>
#include <ctime>
#include <sstream>
using namespace std;

struct Cliente {
	char nombre_cliente[25];
	char direccion[25];
	char ciudad[20];
	char provincia[20];
	long int codigo_postal;
	int anonacimiento;
	int mesnacimiento;
	int dianacimiento;
	double saldo;
};

int getedad(Cliente c) {
	return 0;
}

string Mes() {
	time_t t = time(NULL);
	tm* tiempo = localtime(&t);
	stringstream mes;
	mes<<tiempo->tm_mon + 1;
	return mes.str();
};

string Dia() {
	time_t t = time(NULL);
	tm* tiempo = localtime(&t);
	stringstream dia;
	dia<<tiempo->tm_mday;
	return dia.str();
};

string A�o(){
	time_t t = time(NULL);
	tm* tiempo = localtime(&t);
	stringstream anio;
	anio<< tiempo->tm_year+1900;
	return anio.str();
};


int main() {
	Cliente micliente;
	strcpy_s(micliente.ciudad, "SPS");
	cout << "La ciudad del cliente es: " << micliente.ciudad << endl;
	cout << "La fecha es: " << Dia() << "/" << Mes() << "/" <<A�o()<< "A�o\n";
	return 0;
};


