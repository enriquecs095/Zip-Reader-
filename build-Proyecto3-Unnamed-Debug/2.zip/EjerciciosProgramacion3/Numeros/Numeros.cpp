#include <iostream>

using namespace std;

int main() {

	int numero1, numero2, resultado;
	cout << "Ingrese el numero 1: \n";
	cin >> numero1;
	cout << "Ingrese el numero 2: \n";
	cin >> numero2;
	resultado = numero1 + numero2;
	cout << "El resultado es: " << resultado << " \n";

}