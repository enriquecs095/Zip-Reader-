#pragma once//politica del preprocesador
#ifndef CLIENTE_H
#define CLIENTE_H
#include <cstring>

class Cliente{

private:
char Nombrecliente[25];
char direccion[25];
char ciudad[20];
char provincia[20];
long int codigo_postal;
double saldo;
int anioN;
int mesN;
int diaN;

public:
Cliente();
void setNombreCliente(char[]) ;
char getNombreCliente();
void setDia(int);
int getDia();
void setMes(int);
int  getMes();
void setAnio(int) ;
int  getAnio();
int CalculoEdad(int);
};
#endif