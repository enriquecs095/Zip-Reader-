#include <iostream>
#include <cstring>
#include "Cliente.h"
using namespace std;

int main(){
int dia;
int mes;
int anio;
Cliente c;
char a[25]="Enrique Cruz";
c.setNombreCliente(a);
cout<<"Ingrese el dia de nacimiento del cliente"<<endl;
cin>>dia;
cout<<"Ingrese el mes de nacimiento del cliente"<<endl;
cin>>mes;
cout<<"Ingrese el año de nacimiento del cliente"<<endl;
cin>>anio;
c.setAnio(anio);
c.setMes(mes);
c.setDia(dia);
cout<<"El cliente: "<<c.getNombreCliente()<<" tiene una edad de: "<<c.CalculoEdad(c.getAnio())<<endl;
return 0;

};