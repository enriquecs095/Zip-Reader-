#include "Cliente.h"
#include <iostream>
#include <cstring>

using namespace std;

Cliente::cliente{
strcpy_s(nombre_cliente,"");
}

void cliente:setNombreCliente(char *c){
strcpy_s(nombre_cliente, c);
}

char[] cliente::getNombreCliente(){
return nombre_cliente;
}

void cliente::setAnio(int anio){
strcpy_s(anioN, anio);
}

int cliente::getAnio(){
return  anioN;
}


void cliente::setMes(int mes){
strcpy_s(mesN, mes);

}

int cliente::getMes(){
return  mesN;
}

void cliente::setDia(int dia){
strcpy_s(diaN, dia);

}

int cliente::getDia(){
return  diaN;
}

int cliente::CalculoEdad(int n){
time_t tiempo = time(NULL); 
 struct tm *tlocal = localtime(&tiempo);     
  int anio=tlocal->tm_year+1900;
  int resultado=anio-n;
return resultado;
}
