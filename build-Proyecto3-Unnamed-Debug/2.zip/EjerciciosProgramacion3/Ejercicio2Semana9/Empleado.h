#pragma once
#ifndef EMPLEADO_H
#define EMPLEADO_H

struct EmpleadoRegistro{
int codigo;//4 bytes
char nombre[30];//30 bytes
char puesto[20];//20 bytes
float salario;//4 bytes
bool estado;//1 byte
};//sizeof 59 bytes


class Empleado{

public: 
static void ingresarEmpleados();
static void consultarEmpleados();
static void modificacionSalario(const char*, float);
static int obtenerCantidadRegistros();
};

#endif
