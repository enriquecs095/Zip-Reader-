#include "Empleado.h"
#include <fstream>
#include <iostream>
#include <cstring>

 
void Empleado::ingresarEmpleados(){
std::ofstream archivoE("empleados.dat",std::ios::out | std::ios::binary | std::ios::app);
if(!archivoE){
    std::cout<<"Archivo no existe";
    return;
}
std::cout<<"Ingrese cantidad de empleados a guardar: ";
int cantidad;
std::cin>>cantidad;
for (int i = 0; i < cantidad; i++)
{
    EmpleadoRegistro nuevo;
    std::cout<<"Ingrese codigo del empleado:";
    std::cin>>nuevo.codigo;
    std::cout<<"Ingrese nombre del empleado:";
    std::cin>>nuevo.nombre;
    std::cout<<"Ingrese el puesto del empleado:";
    std::cin>>nuevo.puesto;
    std::cout<<"Ingrese el salario del empleado:";
    std::cin>>nuevo.salario;
    nuevo.estado=1;
    archivoE.write(reinterpret_cast<const char*>(&nuevo),sizeof(EmpleadoRegistro));//sirve para hacer un casteo de bytes a nivel de c++
}
 archivoE.close();
}

void Empleado::consultarEmpleados(){
std::ifstream archivoE("empleados.dat",std::ios::in | std::ios::binary);
if(!archivoE){
std::cout<<"Archivo no existe";
return;
}
archivoE.seekg(0, std::ios::beg);//I will read at the beginnig, this is the cursor on the position zero
EmpleadoRegistro lectura;
archivoE.read(reinterpret_cast<char *>(&lectura), sizeof(EmpleadoRegistro));
while(!archivoE.eof()) {       //while doesn't stay at the end of the file
    std::cout<<"RegistroEmpleado{"<<"codigo: "<<lectura.codigo<<", nombre: "<< 
    lectura.nombre<<", puesto: "<<lectura.puesto<<", salario: "<< lectura.salario<<
    ", estado: "<<lectura.estado<<" }\n";
    archivoE.read(reinterpret_cast<char *>(&lectura), sizeof(EmpleadoRegistro));
    }
archivoE.close();
}


void Empleado::modificacionSalario(const char* nombre, float salario){
 std::fstream archivoE("empleados.dat", std::ios::in | std::ios::out | std::ios::binary);//lectura y escritura
    if(!archivoE){
        std::cout<<"¡Error de lectura en archivo!";
        return; 
    }
 archivoE.seekg(0, std::ios::beg);//posicion para leer
 EmpleadoRegistro lectura;
 archivoE.read(reinterpret_cast<char *>(&lectura), sizeof(EmpleadoRegistro));
 int posicionRegistro=0;
    while(!archivoE.eof()){
        if(strcmp(lectura.nombre, nombre)==0){
            lectura.salario=salario;
            archivoE.seekp(posicionRegistro*sizeof(EmpleadoRegistro), std::ios::beg);//posicion para escritura
            archivoE.write(reinterpret_cast<const char *>(&lectura), sizeof(EmpleadoRegistro));
            return;
        }
        posicionRegistro++;
        archivoE.read(reinterpret_cast<char *>(&lectura), sizeof(EmpleadoRegistro));
    }
 std::cout<<"Registro no encontrado\n";
 archivoE.close();
}//tambien esta tellg (leer) y tellp(escritura) indican la posicion donde esta el cursor 


int Empleado::obtenerCantidadRegistros(){
 std::ifstream archivoE("empleados.dat", std::ios::in, std::ios::binary);
    if(!archivoE){
        std::cout<<"¡Error de lectura en archivo!";
        return; 
    }
 archivoE.seekg(0, std::ios::end);
 int posicionFinal=archivoE.tellg();
 int cantidadRegistros=posicionFinal/sizeof(EmpleadoRegistro);//la cantidad de bytes entre la estructura de
 return cantidadRegistros;//cada registro
}



