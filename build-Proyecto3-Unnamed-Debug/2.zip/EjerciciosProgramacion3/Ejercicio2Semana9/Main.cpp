#include "Empleado.h"
#include <iostream>

int main(){
//Empleado::ingresarEmpleados();
Empleado::consultarEmpleados();
Empleado::modificacionSalario("Enrique", 120000);
Empleado::consultarEmpleados();
}