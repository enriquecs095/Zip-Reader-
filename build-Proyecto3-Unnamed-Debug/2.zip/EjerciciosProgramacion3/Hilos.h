#pragma once
#ifndef HILOS_H
#define HILOS_H

class Hilos{

public:
Hilos();
void Mensaje();
void SubProceso();



};
#endif