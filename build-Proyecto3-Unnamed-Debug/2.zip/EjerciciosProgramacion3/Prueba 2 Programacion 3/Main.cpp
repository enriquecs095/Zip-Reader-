#include "Nodo.h"
#include <iostream>

int main(){
Nodo * nuevo;
nuevo=0;
insertar(&nuevo,(char*) "Enrique");
insertar(&nuevo, (char*)"Ana");
// insertar(&nuevo, (char*)"Roberto");
// insertar(&nuevo, (char*)"Puff Daddy");
// insertar(&nuevo,(char*) "50 cent");
// eliminar(&nuevo,(char*)"Puff daddy");
// if(buscar(&nuevo,(char*) "Ana"))
//  std::cout<<"Se encontro"<<"\n";
//  else
//  {
//     std::cout<<"No se encontro"<<"\n";
//  }
 imprimir(&nuevo);

 if(buscar(&nuevo, (char*)"Enrique")){
     std::cout<<"Se encontro";
     }else{
         std::cout<<"No se encontro";
     }
}