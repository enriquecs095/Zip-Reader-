#include "Nodo.h"
#include <cstring>
#include <iostream>

void insertar(Nodo** _raiz, char* _nombre){//el *nodo nodo viene vacio, hay que insertar los datos primero
Nodo* nuevo= new Nodo;
Nodo* actual= *_raiz;
nuevo->nombre=_nombre;
if(*_raiz==0){
   *_raiz=nuevo;
   return;
}
while(actual!=0){
if(!buscar(&(*_raiz),_nombre)){
    if((strcmp(actual->nombre,_nombre))>0){
        if(actual==(*_raiz)){//reemplazar el inicio de la lista
            nuevo->siguiente=actual;
            actual->anterior=nuevo;
            (*_raiz)=nuevo;
            return;
        }else{
         nuevo->siguiente=actual;
        nuevo->anterior=actual->anterior;
        actual->anterior->siguiente=nuevo;
         actual->anterior=nuevo;
        }
    return;
     } else if(actual->siguiente==0){
            actual->siguiente=nuevo;
            nuevo->anterior=actual;
            return;
        }
}
  actual=actual->siguiente;
}

}


// void eliminar(Nodo** _nodo , char *_nombre){
//    Nodo* actual;
//     while(*_nodo!=0){
//      if(_nombre==(*_nodo)->nombre){

//          delete *_nodo;
//         }
//     }
// }

bool buscar(Nodo** _nodo, char *_nombre){
while(*_nodo!=0){
        if(_nombre==(*_nodo)->nombre){
         return true;
        }
       buscar(&(*_nodo)->siguiente, _nombre);
    }
return false;
}



void imprimir(Nodo** _nodo){
if(*_nodo==0){
    return;
}
std::cout<<" [ "<<(*_nodo)->nombre<<" ] ";
imprimir(&(*_nodo)->siguiente);
}








