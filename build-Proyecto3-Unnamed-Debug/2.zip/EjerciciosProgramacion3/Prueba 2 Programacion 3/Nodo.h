#pragma once
#ifndef NODO_H
#define NODO_H

struct Nodo{
char* nombre;
Nodo* anterior;
Nodo* siguiente;

Nodo(){
anterior=0;
siguiente=0;

}
};

void insertar(Nodo** , char *);
void eliminar(Nodo** , char *);
bool buscar(Nodo**, char *);
void imprimir(Nodo**);

#endif




