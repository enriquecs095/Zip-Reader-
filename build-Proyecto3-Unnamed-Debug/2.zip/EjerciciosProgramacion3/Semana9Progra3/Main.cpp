#include "Nodo.h"
#include <iostream>
#include <cstring>
int main(){
    Nodo* raiz=0;
    int opcion;
    char Nombre[30];
    char* NuevoN;
    bool salir=false;
    do{
        std::cout<<"MENU DE NODOS\n";
        std::cout<<"1. Insertar al inicio\n";
        std::cout<<"2. Insertar al final\n";
        std::cout<<"3. Guardar en Archivo\n";
        std::cout<<"4. Cargar desde Archivo\n";
        std::cout<<"5. Buscar Elemento\n";
        std::cout<<"6. Ordenar Elementos\n";
        std::cout<<"7. Salir\n";
        std::cout<<"Ingrese una opcion: ";
        std::cin>>opcion;
        switch(opcion){
            case 1:
                std::cout<<"Ingrese el nombre: ";
                std::cin>>Nombre;
                NuevoN=new char[strlen(Nombre)];
                strcpy(NuevoN,Nombre);
                insertarAlInicio(&raiz,NuevoN);
            break;

            case 2:
                std::cout<<"Ingrese el nombre: ";
                std::cin>>Nombre;
                NuevoN=new char[strlen(Nombre)];
                strcpy(NuevoN,Nombre);
                insertarAlFinal(&raiz,NuevoN);
            break;

            case 3: 
                std::cout<<"Ingrese el nombre del archivo nuevo: ";
                std::cin>>Nombre;
                NuevoN=new char[strlen(Nombre)];
                strcpy(NuevoN,Nombre);
                GuardarEnArchivo(&raiz,NuevoN);
            break;

            case 4:
                std::cout<<"Ingrese el nombre del archivo para cargar en nodos: ";
                std::cin>>Nombre;
                NuevoN=new char[strlen(Nombre)];
                strcpy(NuevoN,Nombre);
                cargarDesdeArchivo(&raiz,NuevoN);
            break;

            case 5:
                std::cout<<"Ingrese el nombre a buscar: ";
                std::cin>>Nombre;
                NuevoN=new char[strlen(Nombre)];
                strcpy(NuevoN,Nombre);
                if(Buscar(&raiz, NuevoN)){
                    std::cout<<"Se encontro\n";
                }else {
                    std::cout<<"No se encontro\n";
                }
            break;

            case 6:
                ordenar(&raiz);
                imprimir(&raiz);
                std::cout<<"\n";
            break;

            case 7:
                salir=true;
            break;

                default:
                break;
        }
    }while(!salir);

}