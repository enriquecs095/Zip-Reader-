#include "Nodo.h"
#include <cstring>
#include <iostream>
#include <fstream>
#include <cstring>

void insertarAlInicio(Nodo** _inicio, char* _nombre){
Nodo* actual=*_inicio;
Nodo* nuevo=new Nodo();
nuevo->nombre=_nombre;
    if(*_inicio==0){
    *_inicio=nuevo;
    return;
    }
    while(actual->anterior!=0){  
      actual=actual->anterior;
    }
    *_inicio=nuevo;
     actual->anterior=nuevo;
     nuevo->siguiente=actual;
     nuevo->anterior=0;
}


void insertarAlFinal(Nodo** _inicio, char* _nombre){
Nodo* actual=*_inicio;
Nodo* nuevo=new Nodo();
nuevo->nombre=_nombre;
if(*_inicio==0){
    *_inicio=nuevo;
    return;
}    
while(actual->siguiente!=0){
actual=actual->siguiente;
}
actual->siguiente=nuevo;
nuevo->anterior=actual;
nuevo->siguiente=0;
}


void imprimir(Nodo** _nodo){
if(*_nodo==0){
    return;
}
std::cout<<" [ "<<(*_nodo)->nombre<<" ] ";
imprimir(&(*_nodo)->siguiente);
}


void ordenar(Nodo** _inicio){
Nodo* actual=*_inicio;
Nodo* anterior;
Nodo* siguiente;
Nodo* proximo;
if(*_inicio==0){
    return;
}
while(!EstaOrdenado(&(*_inicio))){//si no esta ordenado
        if(strcmp(actual->nombre,actual->siguiente->nombre)>0 && actual->siguiente!=0){//si el primero es mayor al segundo
         if(actual->anterior==0){
            anterior=0;
            siguiente=actual->siguiente;
            proximo=actual->siguiente->siguiente;
            siguiente->siguiente=actual;
            siguiente->anterior=0;
            actual->anterior=siguiente;
            actual->siguiente=proximo;
            proximo->anterior=actual;
            (*_inicio)=siguiente;
            (*_inicio)->siguiente=actual;
            (*_inicio)->anterior=0;
            (*_inicio)->siguiente->siguiente=proximo;   
          }else if(actual->siguiente->siguiente==0){
                anterior=actual->anterior;
                siguiente=actual->siguiente;
                proximo=0;
                anterior->siguiente=siguiente;
                siguiente->anterior=anterior;
                siguiente->siguiente=actual;
                actual->anterior=siguiente;
                actual->siguiente=0;
          }else {
              anterior=actual->anterior;
              siguiente=actual->siguiente;
              proximo=actual->siguiente->siguiente;
              anterior->siguiente=siguiente;
              siguiente->anterior=anterior;
              siguiente->siguiente=actual;
              actual->anterior=siguiente;
              actual->siguiente=proximo;
              proximo->anterior=actual;
          }
     }else if(strcmp(actual->nombre, actual->siguiente->nombre)<0){
         actual=actual->siguiente;
     }
        if(actual->siguiente==0){
            anterior=actual->anterior;
            actual->siguiente=0;
            siguiente=0;
            proximo=0;
            actual=*_inicio;
        }
  }
}


bool EstaOrdenado(Nodo** _inicio){
Nodo* actual=*_inicio;
while(actual->siguiente!=0){
if(strcmp(actual->nombre, actual->siguiente->nombre)>0)
{
    return false;
}
actual=actual->siguiente;
}
return true;
}

void GuardarEnArchivo(Nodo** _nodo, char * _direccion){
    Nodo* actual=*_nodo;
    std::ofstream ArchivoE(_direccion, std::ios::app);
    if(!ArchivoE){
        std::cout<<"Error al cargar";
    }
 if(*_nodo==0){
    return;
 }
 while(actual!=0){
 ArchivoE<<actual->nombre<<"\n";
 actual=actual->siguiente;
 }
 ArchivoE.close();
}

void cargarDesdeArchivo(Nodo** _nodo, char * _direccion){
 char _nombre[30];  
 char* NuevoN; 
  std::ifstream ArchivoL(_direccion, std::ios::in);
  if(!ArchivoL){
      std::cout<<"Error al cargar archivo";
  }
 while(ArchivoL>>_nombre){
     NuevoN=new char[strlen(_nombre)];
     strcpy(NuevoN,_nombre);
     insertarAlFinal(&(*_nodo), NuevoN);
     std::cout<<" [ "<<(*_nodo)->nombre<<" ] ";
     *_nodo=(*_nodo)->siguiente;  
 }
 std::cout<<"\n";
  ArchivoL.close();
}


bool Buscar(Nodo** _nodo, char *_nombre){
    Nodo* actual=*_nodo;
while(actual!=0){
        if(strcmp(_nombre,actual->nombre)==0){
         return true;
        }
        actual=actual->siguiente;
    }
return false;
}
