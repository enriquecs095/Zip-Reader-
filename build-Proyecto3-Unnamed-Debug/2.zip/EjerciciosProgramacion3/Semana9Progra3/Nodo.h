#pragma once
#ifndef NODO_H
#define NODO_H

struct Nodo{

char* nombre;
Nodo* anterior;
Nodo* siguiente;

Nodo(){
anterior=0;
siguiente=0;
}

};

void insertarAlInicio(Nodo**, char *);
void insertarAlFinal(Nodo**, char *);
void ordenar(Nodo**);
bool EstaOrdenado(Nodo**);
void GuardarEnArchivo(Nodo**, char*);//nombre de archivo
void cargarDesdeArchivo(Nodo**, char *);
void imprimir(Nodo**);
bool Buscar(Nodo**, char*);
void ordenar(Nodo**);
bool EstaOrdenado(Nodo**);
#endif
