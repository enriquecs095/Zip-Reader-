#include "Nodo.h"

Nodo::Nodo() :elemento(-1), siguiente(0), abajo(0) {}

Nodo::Nodo(int _elem, Nodo* _sig, Nodo* _abajo){
	this->siguiente = _sig;
	this->elemento = _elem;
	this->abajo = _abajo;
}


void Nodo::setSiguiente(Nodo* _siguiente){
	this->siguiente = _siguiente;
}

Nodo* Nodo::getAbajo(){
	return this->abajo;
}

void Nodo::setElemento(int _elemento){
	this->elemento = _elemento;
}

Nodo* Nodo::getSiguiente(){
	return this->siguiente;
}

void Nodo::setAbajo(Nodo* _abajo){
	this->abajo = _abajo;
}

int Nodo::getElemento(){
	return this->elemento;
}

