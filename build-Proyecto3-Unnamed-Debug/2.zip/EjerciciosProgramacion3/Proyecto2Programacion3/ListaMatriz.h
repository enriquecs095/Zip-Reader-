#pragma once
#ifndef LISTAMATRIZ_H
#define LISTAMATRIZ_H
#include "Nodo.h"
#include<string.h>
#include<string>

using namespace std;

class ListaMatriz
{
private:
	Nodo* primero;
	Nodo* ultimo;
	Nodo* abajo;
	Nodo* organColumnas;
public:
	ListaMatriz();
	bool estaVacia();
	void agregar(int, string);
	void imprimir(string);
	void sumar(ListaMatriz,int,int,ListaMatriz,int, int);
	void restar(ListaMatriz,int,int,ListaMatriz,int,int);
	void multiplicar(ListaMatriz, int, int, ListaMatriz, int, int);
	int Determinante(ListaMatriz, int, int);
	int Iguales(ListaMatriz, int, int);
};
#endif