#include "Matrices.h"
#include "Nodo.h"
#include "ListaMatriz.h"
#include<fstream>
#include<iostream>
#include<cstdlib>
#include<cmath>
#include<string>
#include<stdio.h>

using namespace std;

Matrices::Matrices(void) {}

bool Matrices::CrearDocumento(string _matriz){
std::ofstream ArchivoL(_matriz, std::ios::app);
if(!ArchivoL){
return false;
}
return true;
}


ListaMatriz Matrices::generarMatriz(string _direccion){
	ifstream ArchivoL(_direccion, ios::in);
	string line;
	int x = 0;
	string valor;
	ListaMatriz lista;
	if (!ArchivoL){
		cout << "Error al abrir archivo\n";
		exit(1);
	}else{
		while (!ArchivoL.eof()){
			getline(ArchivoL, line);
			while (x < line.size()){
				if (line.at(x) != ' '){
					valor += line.at(x);
					x++;
				}else{
					lista.agregar(std::atoi(valor.c_str()), _direccion);
					valor = "";
					x++;
				}
			}
			if (x != 0){
				lista.agregar(std::atoi(valor.c_str()), _direccion);
			}
			x = 0;
			valor = "";
		}
		ArchivoL.close();
	}
	return lista;
}

int Matrices::getFilasMatriz(){
	ifstream ArchivoL(getDireccion(), ios::in);
	string line;
	int filas = 0;
	if (!ArchivoL){
		cout << "Direccion incorrecta\n";
		return -1;
	}else{
		while (!ArchivoL.eof()){
			getline(ArchivoL, line);
			filas++;
		}
	}
	return filas;
}

int Matrices::getColumnasMatriz(){
	ifstream ArchivoL(getDireccion(), ios::in);
	string line;
	int x = 0;
	int columnas = 0;
	bool check = true;
	if (!ArchivoL){
		cout << "Direccion incorrecta\n";
		return -1;
	}else{
		getline(ArchivoL, line);
		if (check){
			while (x < line.size()){
				if (line.at(x) == ' '){
					columnas++;
				}
				x++;
			}
			check = false;
		}
		return columnas = columnas + 1;
	}
}

void Matrices::setDireccion(string _dir){
	this->Direccion = _dir;
}

string Matrices::getDireccion(void){
	return this->Direccion;
}

