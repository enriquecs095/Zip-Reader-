#pragma once
#ifndef MATRICES_H
#define MATRICES_H

#include<fstream>
#include<string.h>
#include "ListaMatriz.h"

using namespace std;

class Matrices
{
private:
	string Direccion;

public:
	Matrices(void);
	//Matrices(string);
	ListaMatriz generarMatriz(string);
	void setDireccion(string);
	string getDireccion(void);
	int getFilasMatriz(void);
	int getColumnasMatriz(void);
	bool CrearDocumento(string);
};
#endif