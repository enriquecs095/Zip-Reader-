#include "ListaMatriz.h"
#include "Matrices.h"
#include<iostream>

int main(){

 string nombreMatriz1;
 string nombreMatriz2;
 string nombreMatriz3;
 string nombreDocumento;
 int opcion = 0;
 bool salir=false;
 Matrices matrices1;
 Matrices matrices2;
 ListaMatriz listaMatriz1;
 ListaMatriz listaMatriz2;
 
do{
	std::cout << "OPERACIONES CON MATRICES\n";
	std::cout << "1. Crear Documento\n";
	std::cout << "2. Ver matriz\n";
	std::cout << "3. Suma de matrices\n";
	std::cout << "4. Resta de matrices\n";
	std::cout << "5. Multiplicacion de matrices\n";
	std::cout << "6. Determinante de matrices\n";
	std::cout << "7. Salir\n";
	std::cout << "Ingrese una opcion: ";
	std::cin >> opcion;

	switch(opcion){

				case 1:
				std::cout<<"Ingrese el nombre para crear el documento ejemplo: \"Documento.dat\": ";
                std::cin>>nombreDocumento;
              	  if(matrices1.CrearDocumento(nombreDocumento)){
               		 std::cout<<"Se creo el documento\n";
               		 }else
                	{
                    std::cout<<"Error al crear documento\n";
            		}
			  break;

				case 2:
					std::cout<<"Ingrese el nombre del documento para ver la matriz: ";
					std::cin>>nombreMatriz3;
					matrices1.setDireccion(nombreMatriz3);
					listaMatriz1=matrices1.generarMatriz(nombreMatriz3);
					listaMatriz1.imprimir(nombreMatriz3);
				break;

			  case 3:
			  std::cout << "Nombre matriz 1: ";
				std::cin >> nombreMatriz1;
				std::cout << "Nombre matriz 2: ";
				std::cin >> nombreMatriz2;
				matrices1.setDireccion(nombreMatriz1);
				listaMatriz1 = matrices1.generarMatriz(nombreMatriz1);
				matrices2.setDireccion(nombreMatriz2);
				listaMatriz2 = matrices2.generarMatriz(nombreMatriz2);
				listaMatriz1.sumar(listaMatriz1, matrices1.getFilasMatriz(), matrices1.getColumnasMatriz(), listaMatriz2, 
				matrices2.getFilasMatriz() , matrices2.getColumnasMatriz());
				break;

			case 4:
				std::cout << "Nombre matriz 1: ";
				std::cin >> nombreMatriz1;
				std::cout << "Nombre matriz 2: ";
				std::cin >> nombreMatriz2;
				matrices1.setDireccion(nombreMatriz1);
				listaMatriz1 = matrices1.generarMatriz(nombreMatriz1);
				matrices2.setDireccion(nombreMatriz2);
				listaMatriz2 = matrices2.generarMatriz(nombreMatriz2);
				listaMatriz1.restar(listaMatriz1, matrices1.getFilasMatriz(), matrices1.getColumnasMatriz(), listaMatriz2, 
				matrices2.getFilasMatriz(), matrices2.getColumnasMatriz());
				break;

			case 5:
					std::cout << "Nombre matriz 1: ";
					std::cin >> nombreMatriz1;
					std::cout << "Nombre matriz 2: ";
					std::cin >> nombreMatriz2;
					matrices1.setDireccion(nombreMatriz1);
					listaMatriz1 = matrices1.generarMatriz(nombreMatriz2);
					matrices2.setDireccion(nombreMatriz2);
					listaMatriz2 = matrices2.generarMatriz(nombreMatriz2);
					listaMatriz1.multiplicar(listaMatriz1, matrices1.getFilasMatriz(), matrices1.getColumnasMatriz(), listaMatriz2, 
					matrices2.getFilasMatriz(), matrices2.getColumnasMatriz());
					break;

			case 6:
					
					// std::cout << "Nombre de matriz: ";
					// std::cin >> nombreMatriz1;
					// matrices1.setDireccion(nombreMatriz1);
					// listaMatriz1=matrices1.generarMatriz(nombreMatriz1);
					// listaMatriz1.Determinante(listaMatriz1, matrices1.getFilasMatriz, matrices1.getColumnasMatriz);
					break;

			case 7:
					salir=true;
					break;
			}
	}while(!salir);

}

