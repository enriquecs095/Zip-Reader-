#include "ListaMatriz.h"
#include "Matrices.h"
#include<iostream>
#include<fstream>
#include<string.h>
#include<string>

using namespace std;

int Contador1, Contador2, Contador3;
int verif;	

ListaMatriz::ListaMatriz() :primero(nullptr), ultimo(nullptr),abajo(nullptr), organColumnas(nullptr){
	Contador1 = 0;
	Contador2 = 0;
	Contador3 = 0;
	verif = 0;
}

bool ListaMatriz::estaVacia(void){
	return primero == nullptr;
}

void ListaMatriz::agregar(int _valor, string _nombre){
	Nodo* nuevo = new Nodo(_valor, nullptr, nullptr);
	Matrices matrices;
	matrices.setDireccion(_nombre);
	int columnas = matrices.getColumnasMatriz();
	int filas = matrices.getFilasMatriz();
	if (estaVacia()){
		primero = nuevo;
		ultimo = nuevo;
		abajo = primero;
		organColumnas = primero;
	}else{
		Nodo* actual = ultimo;
		if (verif == 0){
			if (Contador1 < columnas - 1){
				ultimo->setSiguiente(nuevo);
				ultimo = nuevo;
				Contador1++;
			}else{
				abajo->setAbajo(nuevo);
				organColumnas = abajo->getSiguiente();
				abajo = abajo->getAbajo();
				ultimo = abajo;
				verif = 1;
			}
		}else{
			if (organColumnas != nullptr){
				organColumnas->setAbajo(nuevo);
				organColumnas = organColumnas->getSiguiente();
				ultimo->setSiguiente(nuevo);
				ultimo = nuevo;
			}else{
				abajo->setAbajo(nuevo);
				organColumnas = abajo->getSiguiente();
				abajo = abajo->getAbajo();
				ultimo = abajo;
			}
		}
	}
}

void ListaMatriz::imprimir(string _nombre){
	Nodo* recorredor = primero;
	Nodo* abajo = primero;
	Matrices matrices;
	matrices.setDireccion(_nombre);
	int columnas = matrices.getColumnasMatriz();
	int filas = matrices.getFilasMatriz();
	if (estaVacia()){
		cout << "Lista vacia";
		return;
	}else{
		while (recorredor != nullptr){
			cout << "[ " << recorredor->getElemento() << " ]";
			cout << ' ';
			recorredor = recorredor->getSiguiente();
			Contador2++;
			if (Contador2 == columnas){
				cout << '\n';
				recorredor = abajo->getAbajo();
				abajo = abajo->getAbajo();
				Contador2 = 0;
			}
		}
	}
}

void ListaMatriz::sumar(ListaMatriz a, int filasA, int columnasA, ListaMatriz b, int filasB, int columnasB){
	Nodo* recorredorA = a.primero;
	Nodo* recorredorB = b.primero;
	Nodo* abajoA = a.primero;
	Nodo* abajoB = b.primero;
	int reg = 0;
	int suma = 0;
	string nombreMatrizNueva;
	ofstream Resultado;
	ListaMatriz nueva;
	if(a.Iguales(a,filasA, columnasA)==0 && b.Iguales(b, filasB, columnasB)==0){
		if (filasA == filasB && columnasA == columnasB){
		cout << "Nombre de Matriz resultado: ";
		cin >> nombreMatrizNueva;
		cout << '\n';
		cout << "Matriz resultado\n";
		Resultado.open(nombreMatrizNueva, ios_base::app);
		while (recorredorA != nullptr){
			suma = recorredorA->getElemento() + recorredorB->getElemento();
			cout << "[" << suma << "]";
			Resultado << "[" << suma << "]"; //aqui lo agrego al archivo nuevo
			nueva.agregar(suma, nombreMatrizNueva); //aqui lo cargo a la memoria
			recorredorA = recorredorA->getSiguiente();
			recorredorB = recorredorB->getSiguiente();
			reg++;

			if (reg == columnasA){
				cout << '\n';
				Resultado << '\n';
				recorredorA = abajoA->getAbajo();
				abajoA = abajoA->getAbajo();
				recorredorB = abajoB->getAbajo();
				abajoB = abajoB->getAbajo();
				reg = 0;
			}
		}
	}else{
		cout << "Las Matrices no son iguales\n";
	}
	}else {
		cout<<"No son iguales\n";
	}
	Resultado << "\n";
	Resultado.close();
	return;

}

void ListaMatriz::restar(ListaMatriz a, int filasA, int columnasA, ListaMatriz b, int filasB, int columnasB){
	int reg = 0;
	int resta = 0;
	Nodo* recorredorA = a.primero;
	Nodo* recorredorB = b.primero;
	Nodo* abajoA = a.primero;
	Nodo* abajoB = b.primero;
	string nombreMatrizNueva;
	ofstream matrizRespuestaArchivo;
	ListaMatriz nueva;
    if(a.Iguales(a,filasA, columnasA)==0 && b.Iguales(b, filasB, columnasB)==0){
	if(filasA != filasB || columnasA != columnasB) {
	cout << "Las Matrices no son iguales.";
	}
	else if (filasA == filasB && columnasA == columnasB){
		cout << "Nombre de Matriz resultado: ";
		cin >> nombreMatrizNueva;
		cout << '\n';
		cout << "Matriz resultado\n";
		matrizRespuestaArchivo.open(nombreMatrizNueva, ios_base::app);
		while (recorredorA != nullptr){
			resta = recorredorA->getElemento() - recorredorB->getElemento();
			cout << "[" << resta << "]";
			matrizRespuestaArchivo << resta;
			nueva.agregar(resta, nombreMatrizNueva);
			recorredorA = recorredorA->getSiguiente();
			recorredorB = recorredorB->getSiguiente();
			reg++;
			if (reg == columnasA){
				cout << '\n';
				matrizRespuestaArchivo << '\n';
				recorredorA = abajoA->getAbajo();
				abajoA = abajoA->getAbajo();
				recorredorB = abajoB->getAbajo();
				abajoB = abajoB->getAbajo();
				reg = 0;
			}
		}
	}
		 }else {
			 cout<<"No son iguales\n";
		 }
	matrizRespuestaArchivo << "\n";
	matrizRespuestaArchivo.close();
	return;
}

void ListaMatriz::multiplicar(ListaMatriz a,int filasA, int columnasA,ListaMatriz b,int filasB,int columnasB) {
	Nodo* recorredorA = a.primero;
	Nodo* abajoA = a.primero;
	int x = 0, z = 0, y = 0;
	Nodo* recorredorB = b.primero;
	Nodo* abajoB = b.primero;
	int multiplicacion = 0;
	int resultado = 0;
	string nameMatrizC;
	ofstream matrizRespuestaArchivo;
	ListaMatriz c;
	if (columnasA == filasB){
		cout << "Nombre de Matriz resultado: ";
		cin >> nameMatrizC;
		matrizRespuestaArchivo.open(nameMatrizC, ios_base::app);
		cout << '\n';
		cout << "Matriz resultado\n";
		while (z < (filasA * columnasB * filasA)){
			if (x < filasA){
				multiplicacion = (recorredorA->getElemento()) * (recorredorB->getElemento());
				resultado += multiplicacion;
				recorredorA = recorredorA->getSiguiente();
				recorredorB = recorredorB->getAbajo();
				x++;
				z++;
			}else{
				if (y < columnasB){
					y++;
					cout << "[" << resultado << "]";
					matrizRespuestaArchivo << "[" << resultado << "]";
					recorredorA = abajoA;
					recorredorB = abajoB->getSiguiente();
					abajoB = abajoB->getSiguiente();
					if (y == columnasB){
						cout << '\n';
						matrizRespuestaArchivo << '\n';
						recorredorB = b.primero;
						abajoB = b.primero;
						abajoA = abajoA->getAbajo();
						recorredorA = abajoA;
						y = 0;
					}
					x = 0;
					resultado = 0;
				}else{
					cout << '\n';
					matrizRespuestaArchivo << '\n';
					cout << "(" << resultado << ")";
					matrizRespuestaArchivo << "(" << resultado << ")";
					abajoA = abajoA->getAbajo();
					recorredorA = abajoA;
					y = 0;
				}
			}
		}
		cout << "(" << resultado << ")";
		matrizRespuestaArchivo << "(" << resultado << ")";
	}else{
		cout << "Columnas y filas no son iguales\n";
	}
	matrizRespuestaArchivo.close();
	return;
}



int ListaMatriz::Iguales(ListaMatriz a, int fila, int columna){
	int dato = columna * fila;
	int verificar = 1;
	int Fila=0;
	int Columna = 0;
	Nodo* recorredor = a.primero;
	Nodo* abajo = a.primero;
	while (recorredor != nullptr){
		recorredor = recorredor->getSiguiente();
		if(Columna < columna - 1 && recorredor != nullptr){
			Columna++;
			verificar++;
		}else{
			if (Fila < fila - 1){
				Fila++;
				recorredor = abajo->getAbajo();
				abajo = abajo->getAbajo();
				Columna= 0;
				verificar++;
			}
		}
	}
	if (verificar == dato){
		return 0;
	}else {
		return 1;
	}
}
