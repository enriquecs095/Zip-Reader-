#pragma once
#ifndef NODO_H
#define NODO_H

class Nodo
{
private:
	int elemento;
	Nodo* siguiente;
	Nodo* abajo;
	
public:
	Nodo(void);
	Nodo(int, Nodo*, Nodo*);
	int getElemento(void);
	void setSiguiente(Nodo*);
	void setElemento(int);
	void setAbajo(Nodo*);
	Nodo* getAbajo(void);
	Nodo* getSiguiente(void);
};

#endif