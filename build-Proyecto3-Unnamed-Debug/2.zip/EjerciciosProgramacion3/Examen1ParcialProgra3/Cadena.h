#ifndef CADENA_H
#define CADENA_H
#include <iostream>
using namespace std;

class Cadena{

private:
char *cadena;

public:
Cadena(char *);
Cadena(void);
friend Cadena operator+(Cadena &, Cadena &);
friend ostream&  operator<<(ostream&, Cadena &);
int strcmp(Cadena &, Cadena &);
Cadena substr(int , int);

};

#endif