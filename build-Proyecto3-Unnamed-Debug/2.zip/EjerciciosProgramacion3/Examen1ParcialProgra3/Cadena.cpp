#include "Cadena.h"
#include <cstring>

using namespace std;

Cadena::Cadena(char *c){
this->cadena=new char[strlen(c)];
strcpy(this->cadena, c);
}


Cadena::Cadena(void){  
    this->cadena=new char[1];
    strcpy(this->cadena, "");
}


Cadena operator+(Cadena & c1, Cadena &c2){
Cadena resultado;
char *concatenar=new char[strlen(c1.cadena)+strlen(c2.cadena)+1];
strcpy(resultado.cadena, c1.cadena);
strcat(resultado.cadena, c2.cadena);
return resultado;
}


ostream& operator<<(ostream& out, Cadena &c){
out<<c.cadena;
return out;
}


// int Cadena::strcmp(Cadena &c1, Cadena &c2){
// int posicion1;
// int posicion2;
// char * a=new char[strlen(c1)+1];
// strcpy(a,c1.cadena.c_str());
// char *b[strlen(c2)+1]=new char[strlen(c2)+1];
// strcpy(a, c2.cadena.c_str());
// posicion1=(int)a[0];
// posicion2=(int)b[0];
//  if(posicion1==posicion2){
//      return 0;
//     }else if(posicion1<posicion2){
//         return -1;
//     }else{ 
// return 1;
//     }
// }

// Cadena Cadena::substr(int a, int b){
// Cadena resultado;
// int posicion=a;

// char *a[]=new char[strlen(this->cadena)];
// char *b[]=new char [strlen(this->cadena)];
// strcpy(b,this->cadena);
// for (int i = 0; i < b; i++)
// {
//  strcpy(a, b[posicion] )
// posicion++
// }
// return resultado;
// }




