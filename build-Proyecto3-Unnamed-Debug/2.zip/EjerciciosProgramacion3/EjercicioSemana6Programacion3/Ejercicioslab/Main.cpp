#include <iostream>
using std::cout;
using std::endl;

int main(){

int y{5};
int *yptr{nullptr};

yptr=&y;

cout<<"La direccion de memoria de y es:   "<<&y<<endl;
cout<<"La direccion de memoria de yptr es:" <<yptr<<endl;
cout<<"El valor de la variable y es: "<<y<<endl;
cout<<"El valor al que apunta la variable yptr es: "<< *yptr<<endl;
y=9;
cout<<"El valor al que apunta la variable yptr es: "<< *yptr<<endl;// * operador de desreferencia, me da el valor de la variable

}