#include "ListaEnlazada.h"

int main(){
ListaEnlazada lista;
lista.agregar(7);//este es el primero 
lista.agregar(4);
lista.agregar(3);//este es el ultimo
lista.insertar(1,11);
lista.insertar(4,9);

lista.imprimir();

}   