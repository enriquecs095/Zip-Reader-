#include "ListaEnlazada.h"
#include <iostream>

ListaEnlazada::ListaEnlazada(void): primero(nullptr), ultimo(nullptr){}

using std::cout; //cuando solo necesitamos cout


bool ListaEnlazada::estaVacia(void){
    return primero==nullptr;
}

void ListaEnlazada::agregar(int _valor){
Nodo* nuevo=new Nodo(_valor, nullptr); //llamamos el constrcutor nodo con parametros, primero el valor que 
//inicia, luego nullptr porque no sabemos cual valor es el siguiente
if(estaVacia())
{
primero=nuevo;//el primer valor sera el primero y el ultimo con la misma direccion del apuntador
ultimo=nuevo;//solamente cuando la lista se encuentre vacia;
}else{
ultimo->setSiguiente(nuevo);
ultimo=nuevo;
    }                                         
}

void ListaEnlazada::insertar(int posicion, int valor){
if(posicion>cantidadElementos()){
    std::cout<<"Error: Posicion de Nodo incorrecta! \n";
    return;
}
Nodo * nuevo=new Nodo(valor, nullptr);
if(estaVacia()){
primero=nuevo;
ultimo=nuevo;
}else
{
    int posRecorrido=1;
     Nodo*actual=primero;
     Nodo*anterior=nullptr;
     while(actual !=nullptr){
         if(posicion ==posRecorrido){
           if(actual==primero){
             nuevo->setSiguiente(primero);
             primero=nuevo;
           }else
           {
               anterior->setSiguiente(nuevo);
               nuevo->setSiguiente(actual);
           }
           return;
         }
         anterior=actual;
         actual=actual->getSiguiente();
         posRecorrido++;
     } 
}
}



int ListaEnlazada::cantidadElementos(){
Nodo* actual=primero;
int cantidad=0;

while(actual !=nullptr){
cantidad++;
actual=actual->getSiguiente();//
}
return cantidad;
}


void ListaEnlazada::eliminar(int _valor){
    Nodo*anterior=nullptr;
    Nodo*actual =primero;
 if(estaVacia){
     return;
 }else{
     while(actual!=nullptr){
      if(_valor==actual->getValor())
      if(actual==primero){
          primero=actual->getSiguiente();
          delete actual;
      }else if(actual==ultimo){
          ultimo=anterior;
          ultimo->setSiguiente(nullptr);
          delete actual;
      }else
      {
          anterior->setSiguiente(actual->getSiguiente);
          delete actual;
      }
      return;
     }
     anterior=actual;
     actual=actual->getSiguiente();
 }
}

void ListaEnlazada::imprimir(void){
Nodo* actual=primero;
while(actual!=nullptr){
cout<<" ["<<actual->getValor()<<" ]";
actual=actual->getSiguiente();
}
}