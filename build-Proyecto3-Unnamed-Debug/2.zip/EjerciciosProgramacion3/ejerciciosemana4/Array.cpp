#include "Array.h"
using namespace std;
/* 
Array::Array(){

for (int i = 0; i < count; i++){
data[i]=0;

}
*/

Array::Array(int size): size (size){
data=new int[size];
for (int i = 0; i < size; i++){
data[i]=0;
}


Array::Array(const Array& : size(other.size)){
data =new int[size];
for (int i = 0; i < size; i++)
{
data[i]=other.data[i];
}
}

void Array::copyFrom(const Array& other){// en una referencia no hay un destructor

}

bool Array::operator==(const Array& other){
if(size! other.size){
    return false;
}
for (int i = 0; i < size; i++)
{
    if(data[i]!=otherdata[i]){
    return false;
    }
}
    return true;
}

ostream& operator<<(ostream& out, const Array& arr){
bool first=true;
out<<"{";
for (int i = 0; i < arr.getSize(); i++)
{
   if(first){//
   first==false;
   }else{
       out<<",";
   }
}
out<<"}";
return out;
}


};
