
class Array{ // por default los campos son publicos con una clase tipo struct

public:
Array() : size(0), data(nullptr){}
Array(int size);
Array(const Array& other);// para imprimir sin necesidad de desechar los datos de un arraylist este es el copy constructor

~Array(){
    cout<<"Array destructor size is: "<<size << "\n";
    delete[] data;
 }

int getElement(int index){
return data[index];
}

bool operator==(const Array& other);

bool operator !=(const Array & other){
return !operator==(other);
}

Array& operator=(const Array& other){
if(&other != this){// comparar las direcciones del objeto
delete[] data
copyFrom(other);//reasignar los datos que estan en los bloques (delete en realidad no elimina, simplemente dice que esta disponible ese espacio en memoria)
}
return *this;
}

ostream& operator<<(ostream& out, const Array& arr);

void setElement(int index, int value){
data[index]=value;
}

arraRef[0]=1230;//hace referencia a un array
Arra[i]=Array[i]+10//hace referencia a sobrecarga de []

int operator[] (int index) const{ // para que el metodo no modifique el objeto  por eso se utilizar const
return data[index];

}

int getSize() const{// es para no modificar el objeto actual 
return size;

}

private:
void copyFrom(const Array& other);//sirve para el copyassign
int size;
int *data;

};



