#include "Array.h"
#include <iostream>
using namespace std;

int main(){

Array arr(16);
Array arr1(arr);

cout<<"Sizeof(Array) is "<<sizeof(Array)<<"\n"
<<"Sizeof(int) is "<<sizeof(int )<< "\n"
<<"Sizeof(int*) is "<<sizeof(int*)<<"\n";
<<"Sizeof(Array&) is "<<sizeof(Array&)<<"\n";

for (int i = 0; i < arr.getSize(); i++){
arr.setElement(i, i*10);
arr[i]=i*10;
}

arrRef.setElement(0,1230);

for (int i = 0; i < arr.getSize(); i++){
cout<<arr.getElement(i)<<" ";
}
cout<<"\n";



for (int i = 0; i < arr1.getSize(); i++)
{   
}

cout<<"arr3== arr1 is "<<(arr3==arr1)<<endl;//cindicion
cout<<"arr1!= arr is "<<(arr1==arr)<<endl;
cout<< arr1<<"\n";
cout<<arr2<<"\n";


Array arr2;
arr2=arr1;// double free os sea doble liberacion genera copy assign

arr2(32); //gotear memoria
};