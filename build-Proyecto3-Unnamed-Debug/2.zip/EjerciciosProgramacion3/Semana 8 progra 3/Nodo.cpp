#include "Nodo.h"
#include <iostream>


void agregarElemento(Nodo** _raiz, Nodo* _nuevo){

if(*_raiz==0){//quiere decir que el nodo raiz esta vacio
    *_raiz = _nuevo;
}else{
    if(_nuevo->valor >=(*_raiz)->valor){
        agregarElemento(&(*_raiz)->hDerecho, _nuevo);
    }else
    {
        agregarElemento(&(*_raiz)->hIzquierdo, _nuevo);
    }
 }
}


void imprimir(Nodo** _raiz){
if(*_raiz==0){
    return;
}
std::cout<< " [ "<<(*_raiz)->valor<<" ] ";
imprimir(&(*_raiz)->hIzquierdo);
imprimir(&(*_raiz)->hDerecho);
}

