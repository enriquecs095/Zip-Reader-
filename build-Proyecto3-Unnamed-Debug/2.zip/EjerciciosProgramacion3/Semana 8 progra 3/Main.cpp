
#include "Nodo.h"

int main(){
//primero
Nodo* raiz=0;
Nodo* nuevo =new Nodo;
nuevo->valor=40;
agregarElemento(&raiz, nuevo);
//segundo
nuevo =new Nodo;
nuevo->valor=31;
agregarElemento(&raiz, nuevo);
//tercero
nuevo =new Nodo;
nuevo->valor=62;
agregarElemento(&raiz, nuevo);
//cuarto
nuevo =new Nodo;
nuevo->valor=12;
agregarElemento(&raiz, nuevo);
//quinto
nuevo =new Nodo;
nuevo->valor=38;
agregarElemento(&raiz, nuevo);
//sexto
nuevo =new Nodo;
nuevo->valor=55;
agregarElemento(&raiz, nuevo);
//septimo
nuevo =new Nodo;
nuevo->valor=85;
agregarElemento(&raiz, nuevo);

imprimir(&raiz);

}