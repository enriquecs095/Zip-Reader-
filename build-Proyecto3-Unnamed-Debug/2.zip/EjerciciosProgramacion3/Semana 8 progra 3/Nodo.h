#pragma once 

#ifndef NODO_H
#define NODO_H

struct Nodo{

int valor;
Nodo* hDerecho;
Nodo* hIzquierdo;

Nodo(){
valor=-1;
hDerecho=0;//nullptr
hIzquierdo=0;

    }
};

void agregarElemento(Nodo **, Nodo*);
void imprimir(Nodo**);
bool buscarElemento(Nodo**, int);

#endif