#include "ListaOrdenada.h"
#include <iostream>

ListaOrdenada::ListaOrdenada(void):primero(nullptr), ultimo(nullptr){}


bool ListaOrdenada::estaVacia(){
return primero==nullptr;
}

void ListaOrdenada::Agregar(int _valor){
Nodo* nuevo=new Nodo(_valor, nullptr);
if(estaVacia()){
primero=nuevo;
ultimo=nuevo;
}
ultimo->setSiguiente(nuevo);
ultimo=nuevo;
}

void ListaOrdenada::Eliminar(int _valor){
 Nodo* anterior=nullptr;
 Nodo* actual = primero;
if(estaVacia()){
return;
}else{
    if(Buscar(_valor)==1){
      while(actual!=nullptr){
          if(_valor==actual->getValor()){
             if(actual==primero){
                primero=actual->getSiguiente();
                delete actual;
                return;
             }else if(actual==ultimo){
                ultimo=anterior;
                ultimo->setSiguiente(nullptr);
                delete actual;
                return;
             }else{
                 anterior->setSiguiente(actual->getSiguiente());
                delete actual;
                return;
            }
         }  
         actual=actual->getSiguiente();
      }
   }else if(Buscar(_valor)==0){
     std::cout<<"La lista esta vacia\n";
   } else
   {
         std::cout<<"No se encontro el valor\n";
   }
 }
}

int ListaOrdenada::Buscar(int _valor){
Nodo*actual=primero;
if(estaVacia()){
return 0;
}else{
while(actual!=nullptr){
    if(_valor==actual->getValor()){
       return 1;
    }
    actual=actual->getSiguiente();
 }
}
return -1;
}


void ListaOrdenada::eliminarEn(int posicion){
   int posR=1;
   Nodo* actual=primero;
   Nodo* anterior=nullptr;
if(posicion>cantidadElementos()){
std::cout<<"Posicion mayor al rango de los nodos"<<"\n";
}else{
   while(actual!=nullptr){
      if(posicion==posR){
          if(actual==primero){
             primero=actual->getSiguiente();
             delete actual;
               return;
            }else if(actual==ultimo){
               ultimo=anterior;
               ultimo->setSiguiente(nullptr);
               delete actual;
               return;
            }else{
               anterior->setSiguiente(actual->getSiguiente());
               delete actual;
               return;
            }
         }else{
         posR++;
         }
         actual=actual->getSiguiente();
      }
   }
}

int ListaOrdenada::cantidadElementos(){
Nodo* actual=primero;
int cantidad=0;
while(actual!=nullptr){
cantidad++;
actual=actual->getSiguiente();
}
return cantidad;
}


void ListaOrdenada::Imprimir(){
Nodo* actual=primero;
if(primero==ultimo){
   std::cout<<" [ "<<actual->getValor()<<" ] ";
}else {
         while(actual!=nullptr){
               std::cout<<" [ "<<actual->getValor()<<" ] ";
               actual=actual->getSiguiente();
         }
}
std::cout<<"\n";
}