#pragma once
#ifndef LISTAORDENADA_H
#define LISTAORDENADA_H
#include "Nodo.h"

class ListaOrdenada{

private:
Nodo* primero;
Nodo* ultimo;
bool estaVacia(void);
int cantidadElementos(void);

public:
ListaOrdenada(void);
int Buscar(int);
void Agregar(int);
void Imprimir(void);
void eliminarEn(int);
void Eliminar(int);
};

#endif
