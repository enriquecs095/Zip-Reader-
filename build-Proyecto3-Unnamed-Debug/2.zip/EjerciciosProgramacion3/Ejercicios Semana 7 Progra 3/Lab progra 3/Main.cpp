#include "ListaOrdenada.h"
#include <iostream>

int main(){
bool salir=false;
int opcion;
int valor;
int posicion;
ListaOrdenada lista;

do{
std::cout<<"1. Agregar nodo\n";
std::cout<<"2. Buscar nodo\n";
std::cout<<"3. Eliminar nodo\n";
std::cout<<"4. Eliminar en posicion\n";
std::cout<<"5. Imprimir\n";
std::cout<<"6. Salir\n";
std::cout<<"Ingrese una opcion: ";
std::cin>>opcion;
switch(opcion){

    case 1:
            std::cout<<"Ingrese el valor: ";
            std::cin>>valor;
            lista.Agregar(valor);
    break;

    case 2:
            std::cout<<"Ingrese el nodo a buscar: ";
            std::cin>>valor;
            if(lista.Buscar(valor)>0){
                std::cout<<"Se encontro el nodo\n";
            }else if(lista.Buscar(valor)<0){
                std::cout<<"No se encontro el nodo\n";
            }
            else{
                std::cout<<"La lista esta vacia\n";
            }
    break;

    case 3:
            std::cout<<"Ingrese el valor del nodo: ";
            std::cin>>valor;
            lista.Eliminar(valor);
    break;

    case 4:
            std::cout<<"Ingrese la posicion del nodo que desea eliminar: ";
            std::cin>>posicion;
            lista.eliminarEn(posicion);
    break;

    case 5: 
            lista.Imprimir();
    break;
    
    case 6:
            salir=true;
    break; 
 }
 }while(!salir);


}