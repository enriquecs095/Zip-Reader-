#include "ListaCircular.h"
#include <iostream>
using namespace std;

ListaCircular::ListaCircular(void):primero(nullptr), ultimo(nullptr){}

bool ListaCircular::estaVacia(void){
return primero==nullptr;    
}

void ListaCircular::agregar(int _valor){
Nodo* nuevo=new Nodo(_valor, nullptr, nullptr);
if(estaVacia()){
    primero=nuevo;
    ultimo=nuevo;//el siguiente del ultimo apunta al primero, el anterior del primero apunta al ultimo
    primero->setAnterior(ultimo);
    ultimo->setSiguiente(primero);
 }else{
    ultimo->setSiguiente(nuevo);
    nuevo->setAnterior(ultimo); 
    ultimo=nuevo; 
    ultimo->setSiguiente(primero);
    primero->setAnterior(ultimo);
 }
}

void ListaCircular::imprimir(){
 if(estaVacia()){
     return;
 }else{
     Nodo *actual=primero;//apunta al primero
        do{
            cout<<" [ "<<actual->getValor()<<" ] ";
            actual =actual->getSiguiente();
         }while(actual!=primero);
    }
}

void ListaCircular::insertar(int _pos, int _valor){
    if(_pos > obtenerTamano()){
        return;
    }
    Nodo* nuevo=new Nodo(_valor, nullptr, nullptr);
    Nodo* actual=primero;
    int posicion=1;

    do{
        if(posicion==_pos){
            if(actual==primero){
                nuevo->setSiguiente(primero);//antiguo primero
                primero->setAnterior(nuevo);
                primero=nuevo;//el que eta entrando va a ser el primero
                primero->setAnterior(ultimo);//nuevo primero
                ultimo->setSiguiente(primero);
            }else if(actual==ultimo){//insertar en la ultima posicion
                nuevo->setSiguiente(ultimo);
                nuevo->setAnterior(ultimo->getAnterior());
                ultimo->getAnterior()->setSiguiente(nuevo);
                ultimo->setAnterior(nuevo);
            }else{
                nuevo->setSiguiente(actual);
                nuevo->setAnterior(actual->getAnterior());
                actual->getAnterior()->setSiguiente(nuevo);//apunto hacia atras y hacia adelante
                actual->setAnterior(nuevo);
            }
            return;
        }else{
                posicion++;
                actual=actual->getSiguiente();
        }

    }while(actual!=primero);

}

void ListaCircular::eliminar(int _valor){
Nodo*actual=primero;
do{
    if(actual->getValor()==_valor){
            if(actual==primero){
                primero->getSiguiente()->setAnterior(ultimo);
                primero=primero->getSiguiente();
                ultimo->setSiguiente(primero);
                delete actual;
            }else if(actual==ultimo){
                 ultimo->getAnterior()->setSiguiente(primero);
                 ultimo=ultimo->getAnterior();
                 primero->setAnterior(ultimo);
                 delete actual;
            }else{
                actual->getAnterior()->setSiguiente(actual->getSiguiente());
                actual->getSiguiente()->setAnterior(actual->getAnterior());
                delete actual;
            }
            return;
    }
    actual=actual->getSiguiente();
}while(actual!=primero);
}

int ListaCircular::obtenerTamano(){
    int cantidad=0;
if(estaVacia()){
return cantidad;
}
    Nodo* actual=ultimo;
   do{
      cantidad++;
      actual=actual->getAnterior();
   }while(actual!=ultimo);
  return cantidad;
}

void ListaCircular::imprimirReversa(){
if(estaVacia()){
    return;
}
Nodo*actual=ultimo;
do{
cout<<"[ "<<actual->getValor()<<" ]";
actual=actual->getAnterior();
}while(actual!=ultimo);
}
