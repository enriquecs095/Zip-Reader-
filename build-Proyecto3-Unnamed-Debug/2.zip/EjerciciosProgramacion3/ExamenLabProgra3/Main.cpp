#include "Complejo.h"
#include <iostream>

int main()
{
Complejo x;
Complejo y( 4.3, 8.2 );
Complejo z( 3.3, 1.1 );
cout << "x: ";
cout << "\ny: ";
cout << "\nz: ";
x = y + z;
cout << "\n\nx = y + z:" << endl;
cout << " = ";
cout << " + ";
x = y - z;
cout << "\n\nx = y - z:" << endl;
cout << " = ";
cout << " - ";
cout << endl;
}
