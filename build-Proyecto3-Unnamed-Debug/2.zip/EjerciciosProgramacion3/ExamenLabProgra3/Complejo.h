#ifndef COMPLEJO_H
#define COMPLEJO_H
#include <iostream>
using namespace std;

class Complejo{

public:
Complejo(double, double);
Complejo(void);
friend Complejo operator+(Complejo &, Complejo &);
friend Complejo operator-(Complejo &, Complejo &);
friend Complejo operator*(Complejo &, Complejo &);
friend istream& operator<<(istream &, Complejo &);
friend ostream& operator<<(ostream &, Complejo &);
bool operator==(const Complejo &) const;
bool operator!=(const Complejo &other) const{return !(operator==(other))}

private:
double Real;
double Imaginario;

};


#endif