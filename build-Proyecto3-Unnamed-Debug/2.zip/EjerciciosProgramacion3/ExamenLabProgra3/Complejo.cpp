#include "Complejo.h"
#include <iostream>
using namespace std;

Complejo::Complejo(double real, double imaginario){
this->Real=real;
this->Imaginario=imaginario;
}

Complejo::Complejo(void){}

Complejo operator+(Complejo &c1, Complejo &c2){
Complejo resultado;
resultado.Real=c1.Real+c2.Real;
resultado.Imaginario=c1.Imaginario+c2.Imaginario;
return resultado;
}

Complejo operator-(Complejo &c1, Complejo &c2){
Complejo resultado;
resultado.Real=c1.Real-c2.Real;
resultado.Imaginario=c1.Imaginario-c2.Imaginario;
return resultado;
}

Complejo operator*(Complejo &c1, Complejo &c2){
Complejo resultado;
resultado.Real=c1.Real*c2.Real;
resultado.Imaginario=c1.Imaginario*c2.Imaginario;
return resultado;
}


istream& operator>>(istream &in, Complejo c1){
  cout<<"Ingrese el valor real"<<endl;
in>>c1.Real;
    cout<<"Ingrese el valor imaginario"<<endl;
in>>c1.Imaginario;
return in;
}

ostream& operator<<(ostream &out, Complejo &c){
out<<c.Real<<c.Imaginario;
return out;
}

Complejo operator*(const Complejo &c) const
{
    return Complejo((real*c.real)-(imaginaria*c.imaginaria),(imaginaria*c.real)+(c.imaginaria*real));
}

bool operator==(const Complejo &c) const
{
    if(real!=c.real || imaginaria!=c.imaginaria){
        return false;
    }
    return true;
}




