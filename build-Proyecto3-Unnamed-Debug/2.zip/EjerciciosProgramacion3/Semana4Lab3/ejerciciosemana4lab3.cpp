#include <iostream>
#include <fstream>
#include <string>
using namespace std;

int main(){
bool salir=false;
int opcion=0;
int EliminarContenido=0;
string NombreArchivo;
char InformacionArchivo[50];
char DireccionArchivo[30];
ofstream MyFile;

do{

cout<<"Menu de sistema de archivos"<<endl;
cout<<"0. Crear Archivo"<<endl;
cout<<"1. Escribir en archivo"<<endl;
cout<<"2. Verificar si existe"<<endl;
cout<<"3. Borrar contenido de archivo"<<endl;
cout<<"4. Borrar archivo"<<endl;
cout<<"5. Listar archivos y contenido"<<endl;
cout<<"Ingrese una opcion "<<endl;
cin>>opcion;

switch(opcion){

case 0:
cout<<"Ingrese el nombre del archivo"<<endl;
cin>>NombreArchivo;
MyFile.open(NombreArchivo);
break;

case 1:
cout<<"Ingrese lo que ba a escribir en el archivo"<<endl;
cin>>InformacionArchivo;
MyFile<<InformacionArchivo<<endl;
MyFile.close();
break;

case 2:
cout<<"Ingrese la direccion del archivo "<<endl;
cin>>DireccionArchivo;
if(MyFile.open(DireccionArchivo)){
cout<<"Archivo existe"<<endl;
}else
{
    cout<<"Archivo no existe"<<endl;
}
break;

case 3:
cout<<"Ingrese el nombre del archivo a modificar"<<endl;
cin>>
cout<<"Desea borrar el contenido del archivo 1.Si  2.No"<<endl;
cin>>EliminarContenido;
if(EliminarContenido){
MyFile.clear();
cout<<"Hecho"<<endl;
}
break;

case 4:
cout<<"Desea borrar el archivo 1.Si  2.No"<<endl;
cin>>EliminarContenido;
if(EliminarContenido){
MyFile.close();
if(remove(DireccionArchivo)){
cout<<"Hecho"<<endl;
}
}
break;

case 5:
cout<<"Listando archivos"<<endl;
break;

case 6:
salir=true;
break;

default: 
cout<<"Ingrese una opcion correcta "<<endl;
break;
}

}while(salir!=true);

return 0;

};



