#include <iostream>

using namespace std;

void NumberFunction(int i){
cout<<"The number is: "<<i<<endl;
i++;
if(i<10)
NumberFunction(i);
}

int Potencia(int base, int exp, int resultado){
if(exp==0){
return 1;
}
resultado=base*Potencia(base, exp-1, resultado);
cout<<resultado<<endl;
return resultado;
}


int main(){

int i=0;
int numero=2;
int potencia=5;
int resultado=0;
NumberFunction(i);
Potencia(numero, potencia, resultado);

return 0;

};
