#pragma once
#include "Person.h"

class Student : public Person {


public:
	Student(std::string _id, std::string fname, std::string lname, unsigned int _age) :
	Person(_id,fname,lname,_age){}


};