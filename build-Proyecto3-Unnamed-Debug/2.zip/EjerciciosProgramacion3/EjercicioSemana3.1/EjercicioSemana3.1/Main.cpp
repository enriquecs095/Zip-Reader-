#include <iostream>
#include "Person.h"
#include "Student.h"
int main() {

	Person person("001","Ivan", "Deras",50);
	Student student;

}