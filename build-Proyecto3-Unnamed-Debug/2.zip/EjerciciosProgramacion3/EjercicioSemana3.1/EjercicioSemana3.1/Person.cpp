#include "Person.h"


void Person::printData() {
	std::cout << "First name: " << firstname << "\n";

}
class Person {

public:

	std::string Person::getId() {
		return id;

	};

	void Person::setId(std::string id) {

		id = _id;
	};

	std::string Person::getFirstName() {
		return FirstName;

	};

	void Person::setFirstName(std::string Firstname) {

		FirstName = Firstname;
	};

	std::string Person::getFirstName() {
		return FirstName;

	};

	void Person::setFirstName(std::string Firstname) {

		FirstName = Firstname;
	};

	std::string Person::getLastName() {
		return LastName;

	};

	void Person::setLastName(std::string Lastname) {

		LastName = Lastname;
	};

	std::string Person::getAge() {
		return Age;

	};

	void Person::setAge(std::string age) {

		Age = age;
	};

};