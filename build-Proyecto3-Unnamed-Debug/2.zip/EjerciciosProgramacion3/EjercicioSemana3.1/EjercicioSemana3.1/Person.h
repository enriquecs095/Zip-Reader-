#include <string>
#include <iostream>
class Person {
public:

	Person(std::string _id, std::string fname, std::string lname, unsigned int _age) {
		id = _id;
		FirstName = fname;
		LastName = lname;
		Age = _age;
	};

	//Person(std::string _id, std::string fname, std::string lname, unsigned int _age):
	//i(_id), first_name(fname), last_name(lname), age(_age){}
	//Person(){}

	std::string getId();
	void setId(std::string setId);
	std::string getFirstName();
	void setFirstName(std::string str);
	std::string getLastName();
	void setLastName(std::string str);
	unsigned int getAge();
	void setAge(int age);
	void printData();
private:
	std::string id;
	std::string FirstName;
	std::string LastName;
	unsigned int Age;
	float weight;
	float height;
};