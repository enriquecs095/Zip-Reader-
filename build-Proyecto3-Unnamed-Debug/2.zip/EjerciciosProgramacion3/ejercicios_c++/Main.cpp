#include <iostream>
#include "Nod.h"

int main(){
std::cout<<"Hola mundo\n";



};