#include <iostream>

class Nod{

public:
nod();
nod(int v);
int getVal();
int getValSigs();
nod *sig;

private:
int valor;

};

