
#include "Hilos.h"
#include <iostream>
#include <thread>

Hilos::Hilos(){}

void Hilos::Mensaje(){

std::thread hilo(SubProceso, this);
hilo.join();
      for (int i = 0; i < 5; i++){
        std::cout<<"Esto es una salida de consola normal\n";
    }
}

void Hilos::SubProceso(){
    for (int i = 0; i < 5; i++)
        {
         std::cout<<"Esto es una salida de consola desde un hilo\n";
        }
}