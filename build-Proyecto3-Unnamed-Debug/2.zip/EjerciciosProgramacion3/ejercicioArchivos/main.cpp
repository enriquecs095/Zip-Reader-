

#include <conio.h>
#include "Notas.h"

int main()
{

	//Notas::consultarAlumnos();
	//Notas::registrarAlumnos();

	//Notas::registrarMaterias();
	//Notas::consultarMaterias();

	//Notas::registrarNotas();

	Notas::consultarNotas();

	getch();
}